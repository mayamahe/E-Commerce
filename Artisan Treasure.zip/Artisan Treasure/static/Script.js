document.getElementById("login").addEventListener("click",function(){
    window.open("/login",'_blank');

});
document.getElementById("reclog").addEventListener("click",function(){
    window.open("/login",'_blank');

});
document.getElementById("signup").addEventListener("click",function(){
    window.open("/register",'_blank');
});
document.getElementById("top").addEventListener("click",function(){
    window.location.href="#nav";
});
function HeartColor(icon) {
    // Get the current color of the heart icon
    var currentColor = icon.style.color;
  
    if (currentColor === "red") {
      icon.style.color = "";
    } else {
      
      icon.style.color = "red";
    }
  }
  
  document.getElementById("categorySearchForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const selectedCategory = document.getElementById("categorySelect").value;
    
    // Redirect to the selected category page
    if (selectedCategory !== "categories") {
        window.location.href = selectedCategory; 
    }
});

// Function to load the cart from localStorage when the page loads
function loadCart() {
    const cartData = localStorage.getItem('cart');
    if (cartData) {
        cart = JSON.parse(cartData);
        cartTotal = calculateCartTotal();
    }
    updateCart();
}

// Function to save the cart to localStorage
function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

// Calculate the cart total
function calculateCartTotal() {
    return cart.reduce((total, item) => total + item.price, 0);
}

$(document).ready(function() {
    // Load the cart from localStorage when the page loads
    loadCart();
    
    $('.add-to-cart').click(function () {
        const name = $(this).data('name');
        const price = parseFloat($(this).data('price'));

        cart.push({ name, price });
        cartTotal = calculateCartTotal();
        
        // Save the cart to localStorage
        saveCart();

        updateCart();
    });

    $('#cartModal').on('show.bs.modal', function () {
        updateCart();
    });

    // Checkout button click handler
    $('#checkoutButton').click(function () {
        if (cart.length === 0) {
            alert('Your cart is empty. Add items to your cart before checking out.');
        } else {
            // Simulate a checkout process (you can replace this with your actual checkout logic)
            alert('Checkout successful. Thank you for your purchase!');
            
            // Clear the cart, save it to localStorage, and update the modal
            cart = [];
            cartTotal = 0;
            saveCart();
            updateCart();
        }
    });
});

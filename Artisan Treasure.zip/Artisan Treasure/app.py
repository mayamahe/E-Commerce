from flask import Flask, render_template, request, flash, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = "123"

con = sqlite3.connect("MYDB.db")
con.execute("create table if not exists customer(pid integer primary key, name text, address text, contact text, mail text, password text)")
con.close()

@app.route('/')
def index():
    logged_in = session.get("logged_in", False)
    user_name = session.get("name", None)
    return render_template('index.html', logged_in=logged_in,user_name=user_name)

@app.route('/login', methods=["GET", "POST"])
def login():
    if request.method == 'POST':
        name = request.form['name']
        password = request.form['password']
        con = sqlite3.connect("MYDB.db")
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("select * from customer where name=? and password=?", (name, password))
        data = cur.fetchone()

        if data:
            session["name"] = data["name"]
            session["password"] = data["password"]
            session["logged_in"] = True  # Flag for a successful login
            return redirect(url_for("index"))
        else:
            flash("Username and Password Mismatch", "danger")

    return render_template('login&signup.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        mail = request.form['mail']
        password = request.form['password']
        cnfpassword = request.form['cnfpassword']
        address = request.form['address']
        contact = request.form['contact']
        
        if password != cnfpassword:
            flash("Passwords do not match", "danger")
        else:
            con = sqlite3.connect("MYDB.db")
            cur = con.cursor()
            cur.execute("insert into customer(name, address, contact, mail, password) values (?, ?, ?, ?, ?)", (name, address, contact, mail, password))
            con.commit()
            flash("Registration Successful", "success")
            con.close()
            return render_template('login&signup.html')
    return render_template('register.html')
@app.route('/logout', methods=["POST"])
def logout():
    session.pop("name", None)
    session.pop("password", None)
    session["logged_in"] = False
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)